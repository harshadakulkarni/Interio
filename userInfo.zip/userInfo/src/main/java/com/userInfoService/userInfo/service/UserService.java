package com.userInfoService.userInfo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.userInfoService.userInfo.config.JwtTokenUtil;
import com.userInfoService.userInfo.dto.LoginDto;
import com.userInfoService.userInfo.dto.UserDto;
import com.userInfoService.userInfo.exception.UserNotFoundException;
import com.userInfoService.userInfo.model.User;
import com.userInfoService.userInfo.repository.UserRepository;
@Service
public class UserService {

	@Autowired 
	UserRepository userRepository;
	
	@Autowired
	JwtTokenUtil jwtTokenUtil;
	
	
	private final Logger logger = LoggerFactory.getLogger(getClass());

	
	public List<User> getAllUsers() {
		List<User> user = new ArrayList<User>();  
		userRepository.findAll().forEach(user1 -> user.add(user1)); 
		return user; 
		
	}

	public User getUserById(int userid) {
		return userRepository.findById(userid).get(); 
	}

	public void deleteUser(int userid) {
		// TODO Auto-generated method stub
		userRepository.deleteById(userid); 	
	}

	public void saveOrUpdateUser(User user)  {
		// TODO Auto-generated method stub
		
		try {
			userRepository.save(user);
			//userdto.setCode();
		}
		
		catch (Exception e) {
				System.out.println("Exception" +e);
		}
	
	}
	public String login(LoginDto loginDto) {
		String msg;
		User user = loadUserByEmailId(loginDto.getEmailId());
		if(user.getEmailId() .equals(loginDto.getEmailId())  && user.getPassword() .equals(loginDto.getPassword()))
		{
			msg = "User Login Successfull";
			System.out.println("User Login Successfull");
			 final String token = jwtTokenUtil.generateToken(loginDto);
			 logger.info("JWT Token ------------>"+token);
		}
		else
		{
			msg = "User Login Failed";
			System.out.println("User Login Failed");
			
		}
		
		return msg;
	}
	@Transactional
	public User loadUserByEmailId(String emailid) throws UserNotFoundException {
		User user = userRepository.findByemailId(emailid);
			
		System.out.println("user" +user);
		return user;
	}
}
