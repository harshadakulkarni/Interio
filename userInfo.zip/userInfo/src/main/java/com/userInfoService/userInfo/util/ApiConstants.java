package com.userInfoService.userInfo.util;

public final class ApiConstants {
	public static final String REQUESTID = "X-Request-ID";
	public static final String PATH_COMMENT = "/comment";
	public static final String PATH_SUB_COMMENT = "/subcomment";
	public static final String PATH_USER = "/user";
	public static final String PATH_PROFANITY = "/profanityword";
	public static final String PATH_EMOJI= "/emoji";
	public static final String ROUTE_SAVE = "/save";
	public static final String ROUTE_GET_LIST = "/list";
	public static final String ROUTE_LIST = "/list";
	public static final String ROUTE_DELETE = "/delete";
	public static final String ROUTE_UPDATE = "/update";
	public static final String ROUTE_OAUTH = "/oauth";
	public static final String ROUTE_GET = "/get";
	public static final String AUTHORIZATION = "Authorization";
	public static final String ROUTE_GET_LIST_SUB_COMMENT = "getListSubComments";
	public static final String ROUTE_DELETE_SUB_COMMENT = "deleteSubComment";
	public static final String ROUTE_GET_LIST_PROFANITY_WORDS = "getProfanityWordsList";
	public static final String APPLICATION_JSON = "application/json";
	public static final String ALLOW_CREDENTIALS = "true";
	public static final String ALLOW_ORIGINS_HEADERS = "*";
}
