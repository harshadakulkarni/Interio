package com.userInfoService.userInfo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.userInfoService.userInfo.config.JwtTokenUtil;
import com.userInfoService.userInfo.dto.LoginDto;
import com.userInfoService.userInfo.dto.UserDto;
import com.userInfoService.userInfo.exception.UserErrorResponse;
import com.userInfoService.userInfo.model.User;
import com.userInfoService.userInfo.service.UserService;
import com.userInfoService.userInfo.util.ApiConstants;
import com.userInfoService.userInfo.util.ErrorConstants;


@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(value="/UserInfo/")
@RestController
public class UserController {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());

	
	
	@Autowired
	JwtTokenUtil jwtTokenUtil;
	
	
	@RequestMapping(value="hello")
	
	public String hello()
	{
		System.out.println("calllliiii");
		return "hello";
	}
	@Autowired  
	UserService userService ;  
	//creating a get mapping that retrieves all the books detail from the database   
	@GetMapping("getAllUsers")  
	private List<User> getAllUsers()   
	{  
	return userService.getAllUsers();  
	}  
	//creating a get mapping that retrieves the detail of a specific book  
	@GetMapping("/user/{userid}")  
	private User getUser(@PathVariable("userid") int userid)   
	{  
		 logger.info("success"+userService.getUserById(userid));
	return userService.getUserById(userid);  
	}  
	//creating a delete mapping that deletes a specified book  
	@DeleteMapping("/user/{userid}")  
	private void deleteUser(@PathVariable("userid") int userid)   
	{  
		userService.deleteUser(userid);  
	}  
	//creating post mapping that post the book detail in the database  
	@PostMapping("saveUser")  
	private ResponseEntity<Object> saveUser(@RequestHeader(value = ApiConstants.REQUESTID) String requestId,@RequestBody User user)  
	{   
		 userService.saveOrUpdateUser(user);
		 logger.info("success");
		 UserDto userdto = new UserDto();
		 userdto.setCode(400);
		 userdto.setStatus("suceessfull");
		 userdto.setRequestId(requestId);
		 
	return new ResponseEntity<>(userdto,HttpStatus.CREATED);
	}  
	
	@PostMapping("login")  
	private ResponseEntity<Object> login(@RequestHeader(value = ApiConstants.REQUESTID) String requestId,@RequestBody LoginDto loginDto)  
	{  
		 String res = userService.login(loginDto);
		 UserDto userdto = new UserDto();
		 userdto.setCode(200);
		 userdto.setStatus(res);
		 userdto.setRequestId(requestId);
		 logger.info("success"+userdto);
	   	return new ResponseEntity<>(userdto,HttpStatus.CREATED);
	}  
 	@ExceptionHandler
	public ResponseEntity<UserErrorResponse> handleException(Exception ex){
		UserErrorResponse errorResponse = new UserErrorResponse();
	    errorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
	    errorResponse.setMessage(ex.getMessage());
	    errorResponse.setTimeStamp(System.currentTimeMillis());
	    return new ResponseEntity<UserErrorResponse>(errorResponse,HttpStatus.BAD_REQUEST);
	}
	
}  

	
	
	

