package com.userInfoService.userInfo.util;

public enum ErrorConst {

}
