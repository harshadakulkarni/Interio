package com.userInfoService.userInfo.controller;

public class JwtAuthenticationController {

}
