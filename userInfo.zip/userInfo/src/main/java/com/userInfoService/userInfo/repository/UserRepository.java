package com.userInfoService.userInfo.repository;

import com.userInfoService.userInfo.exception.UserNotFoundException;
import com.userInfoService.userInfo.model.User;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
 
public interface UserRepository extends JpaRepository<User, Integer>   {

	User findByemailId(String emailid) throws UserNotFoundException;;



}
