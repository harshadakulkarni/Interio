package com.userInfoService.userInfo.util;

public final class ErrorConstants {

	public static final String SUCESS = "200";
	public static final String RESOURCE_NOT_FOUND = "404";
	public static final String BAD_REQUEST = "400";
	public static final String CREATED = "201";
	public static final String UNAUTHORIZED = "401";
	public static final String UNSUPPORTED_TYPE = "415";
	public static final String SERVER_ERROR = "415";
}
