package com.userInfoService.userInfo.interfaceService;

public interface iUserService {

}
