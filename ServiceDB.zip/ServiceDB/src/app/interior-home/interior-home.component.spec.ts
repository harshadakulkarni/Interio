import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InteriorHomeComponent } from './interior-home.component';

describe('InteriorHomeComponent', () => {
  let component: InteriorHomeComponent;
  let fixture: ComponentFixture<InteriorHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InteriorHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InteriorHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
