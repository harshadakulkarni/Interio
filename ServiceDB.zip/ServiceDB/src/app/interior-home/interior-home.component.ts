import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interior-home',
  templateUrl: './interior-home.component.html',
  styleUrls: ['./interior-home.component.css']
})
export class InteriorHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
