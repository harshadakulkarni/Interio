import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  
 // url = "http://ec2-18-224-153-220.us-east-2.compute.amazonaws.com:4500/Category";
   url = "http://microbytes.co.in:80/Category";
  
  constructor( private _http: HttpClient) { }
  
  createCat( catName:string){
    const body = {
      catName: catName 
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };

    return this._http.post( this.url, body, httpOptions );
  }

  retriveCategory()
  {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };
    
    return this._http.get(this.url, httpOptions);
  }
}
