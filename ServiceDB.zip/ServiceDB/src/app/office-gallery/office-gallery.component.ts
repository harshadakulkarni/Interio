
import { Component, OnInit } from '@angular/core';
import { ManageProjectService } from '../manage-project.service';
import { Data } from '@angular/router';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FeedbackService } from '../feedback.service';

@Component({
  selector: 'app-office-gallery',
  templateUrl: './office-gallery.component.html',
  styleUrls: ['./office-gallery.component.css']
})


export class OfficeGalleryComponent implements OnInit {

  constructor(config: NgbCarouselConfig, private _projectService: ManageProjectService, private modalService: NgbModal, private _feedbackService: FeedbackService) {
    config.showNavigationArrows = true;
    config.showNavigationIndicators = false;
    config.interval = 3000;
    config.pauseOnHover = false;
  }

  Data = {
    project: String,
    images: []
  }
  img = [];
  selectedCat: string;
  closeResult: string; //ngmodal
  // Dataset :Object[];
  list: Data = [];


  CommentData = {
    name: String,
    feedback: String,
    rating: Number
  }

  comments = [];
  rating_readonly = true


  customer_rating = {
    name:"",
    rating: 0,
    cust_feedback:""
  }

  onSubmit()
  {
    this._feedbackService.InsertFeedback(this.customer_rating.name, this.customer_rating.cust_feedback, this.customer_rating.rating)
    .subscribe((response)=>{
      console.log(response);
    })
  }

  feedback() {
    this._feedbackService.getFeedback()
      .subscribe((response) => {
        const result = response;

        for (var i = 0; i < response['length']; i++) {
          this.comments.push({ name: result[i]['name'], feedback: result[i]['feedback'], rating: result[i]['rating'] });
        }
      });


  }


  open(content, categoryy) {
    this.img = [];
    this.selectedCat = categoryy;
    this._projectService.retrieveImages('office', categoryy)
      .subscribe((response) => {
        for (let count = 0; count < response["length"]; count++)
          this.img.push(response[count]);
      });

    console.log(this.img);


    this.modalService.open(content, { size: 'lg', centered: true }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }




  ngOnInit() {
    this._projectService.retriveProject('office')
      .subscribe((response) => {
        for (let count = 0; count < response["length"]; count++) {
          // this.Dataset[count].project = response[count];
          // this.Dataset[count].images.push('h');
          // this.list.push({project:response[count]});
          this._projectService.retrieveImages('office', response[count])
            .subscribe((resp) => {
              this.list.push({ project: response[count], images: resp });
            });

        }
      });
    this.feedback();
  }

}
