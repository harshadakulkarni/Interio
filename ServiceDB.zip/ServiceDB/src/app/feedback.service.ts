import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  // url = "http://ec2-18-224-153-220.us-east-2.compute.amazonaws.com:4500/Feedback";
    url = "http://microbytes.co.in:4200/Feedback";
   constructor(private http: HttpClient) { }
 
   
   getFeedback(){
    const body = {
    
    }; 

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };

    return this.http.get( this.url, httpOptions );
   }


   InsertFeedback(name:String, feedback:String, rating:Number){

    const body = {
      name: name,
      feedback: feedback,
      rating:rating
    };

    //const headers = new Headers({ 'Content-Type': 'application/json' });
    //const requestOptions = new RequestOptions({ headers: headers });

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };

    return this.http.post( this.url, body, httpOptions );
  }
}
