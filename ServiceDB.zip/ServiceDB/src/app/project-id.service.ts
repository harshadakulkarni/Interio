import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProjectIDService {

  url = "http://ec2-18-224-153-220.us-east-2.compute.amazonaws.com:4500/createProject";
  // url = "http://localhost:4500/createProject";

  constructor( private _http:HttpClient) { }

  createProject( projectID: string, categoryName: string)
  {
    const body = {
      projectID: projectID,
      categoryName: categoryName
    };

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };

    return this._http.post(this.url, body, httpOptions);
  }
}
